<template>
  <v-card>
    <v-flex xs12 sm10>
      <v-tree url="/item/category/list"
              :isEdit="isEdit"
              @handleAdd="handleAdd"
              @handleEdit="handleEdit"
              @handleDelete="handleDelete"
              @handleClick="handleClick"
      />
    </v-flex>
  </v-card>
</template>

<script>
import {treeData} from "../../mockDB";

export default {
  name: "category",
  data() {
    return {
      isEdit: true,
      treeData
    }
  },
  methods: {
    handleAdd(node) {
      console.log("add .... ");
      console.log(node);
      this.$http({
        method: "post",
        url: "/item/category/saveCategory",
        data: node
      }).then(() => {
        // 关闭窗口
        this.$emit("close");
        this.$message.success("添加成功！");
      }).catch(() => {
        this.$message.error("添加失败！");
      });
    },
    handleEdit(id, name) {
      console.log("edit... id: " + id + ", name: " + name)
      this.$http({
        method: "post",
        url: "/item/category/updateCategory",
        data: {id, name}
      }).then(() => {
        // 关闭窗口
        this.$emit("close");
        this.$message.success("修改成功！");
      }).catch(() => {
        this.$message.error("修改失败！");
      });
    },
    handleDelete(id) {
      console.log("delete ... " + id)
      this.$http({
        method: "post",
        url: "/item/category/deleteCategory?id=" + id,
        data: id
      }).then(() => {
        // 关闭窗口
        this.$emit("close");
        this.$message.success("删除成功！");
      }).catch(() => {
        this.$message.error("删除失败！");
      });
    },
    handleClick(node) {
      console.log(node)
    }
  }
};
</script>

<style scoped>

</style>
